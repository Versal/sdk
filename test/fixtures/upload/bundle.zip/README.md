Default Gadget Template
=========================

This is a gadget template for Versal SDK. For instructions, see Versal SDK: https://github.com/Versal/sdk.

Navigate to the gadget's directory and run 'versal preview' to preview and develop the gadget.