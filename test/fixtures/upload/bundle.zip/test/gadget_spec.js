var assert = require("assert");

describe("Gadget", function() { 
  it("should have some test inside", function(){
    assert.equal(1,1);
  });
});