define([], function(){
  return function(){
    return Math.floor(Math.random() * 100) + 1;
  }
});