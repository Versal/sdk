var assert = require("assert");

describe("Another", function() { 
  it("should have some test inside", function(){
    assert.equal(1,1);
  });
});